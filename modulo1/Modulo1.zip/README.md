# curso


sass --watch scss:css --style compact

sass --watch scss:css --style compressed

sass --watch scss/style.scss:css/style.css --style compressed